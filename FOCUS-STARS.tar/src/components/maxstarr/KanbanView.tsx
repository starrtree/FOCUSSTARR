'use client';

import KanbanBoard from './KanbanBoard';

export default function KanbanView() {
  return (
    <div>
      <KanbanBoard />
    </div>
  );
}
